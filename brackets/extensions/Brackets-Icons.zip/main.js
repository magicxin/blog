define(['require', 'exports', 'module', './dist/main'], function (require, exports, module) {
	
});