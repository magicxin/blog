npm i
zip -r brackets.zip . -x \*.git\*