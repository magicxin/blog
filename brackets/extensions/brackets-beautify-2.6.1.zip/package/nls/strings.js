define(function (require, exports, module) {
    'use strict';

    module.exports = {
        root: true,
        de: true,
        es: true,
        fa: true,
        it: true,
        ja: true,
        pl: true,
        ro: true,
        'zh-cn': true,
        ru: true
    };
});
